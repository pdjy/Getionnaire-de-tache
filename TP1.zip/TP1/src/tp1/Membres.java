
package tp1;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author perrault
 */
public class Membres extends javax.swing.JFrame {
    Connection_DB conn;
    Statement stm;
    ResultSet Rs;
    DefaultTableModel model = new DefaultTableModel();
    /**
     * Creates new form Membre
     */

    public Membres() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        ID_Membre = new javax.swing.JLabel();
        Nom_Membre = new javax.swing.JLabel();
        jTextField_ID = new javax.swing.JTextField();
        jTextField_Nom = new javax.swing.JTextField();
        Ajouter_Membre = new javax.swing.JButton();
        Modifier_Membre = new javax.swing.JButton();
        Supprimer_Membre = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table_Membre = new javax.swing.JTable();
        Back_To_Menu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Lucida Bright", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Gestion des membres");

        ID_Membre.setText("ID");

        Nom_Membre.setText("Nom");

        jTextField_Nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_NomActionPerformed(evt);
            }
        });

        Ajouter_Membre.setText("Ajouter");
        Ajouter_Membre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ajouter_MembreActionPerformed(evt);
            }
        });

        Modifier_Membre.setText("Modifier");
        Modifier_Membre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Modifier_MembreActionPerformed(evt);
            }
        });

        Supprimer_Membre.setText("Supprimer");
        Supprimer_Membre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Supprimer_MembreActionPerformed(evt);
            }
        });

        Table_Membre.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        Table_Membre.setColumnSelectionAllowed(true);
        jScrollPane1.setViewportView(Table_Membre);
        Table_Membre.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        Back_To_Menu.setText("Retour");
        Back_To_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Back_To_MenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ID_Membre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Nom_Membre, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField_ID)
                                    .addComponent(jTextField_Nom)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Back_To_Menu)
                                .addGap(0, 137, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(Ajouter_Membre, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Modifier_Membre, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Supprimer_Membre)
                                .addGap(80, 80, 80)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ID_Membre, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Nom_Membre, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField_Nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Supprimer_Membre)
                    .addComponent(Modifier_Membre)
                    .addComponent(Ajouter_Membre)
                    .addComponent(Back_To_Menu))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField_NomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_NomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_NomActionPerformed

    private void Back_To_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Back_To_MenuActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_Back_To_MenuActionPerformed

    private void Ajouter_MembreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ajouter_MembreActionPerformed
        // TODO add your handling code here:
        if(("".equals(jTextField_ID.getText()))||("".equals(jTextField_Nom.getText()))){
            JOptionPane.showMessageDialog(null,"Il faut remplir toutes les cases.");
        }else{
        InsertionMembre();
        //AfficheInfoMembre();
        }
    }//GEN-LAST:event_Ajouter_MembreActionPerformed

    private void Supprimer_MembreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Supprimer_MembreActionPerformed
        // TODO add your handling code here:
         int Id_membre = Integer.valueOf(JOptionPane.showInputDialog("Entrer l'ID du membre à supprimer"));
         SuppressionMembre(Id_membre);
         //AfficheInfoMembre();
    }//GEN-LAST:event_Supprimer_MembreActionPerformed

    private void Modifier_MembreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Modifier_MembreActionPerformed
        // TODO add your handling code here:
        if(("".equals(jTextField_ID.getText()))||("".equals(jTextField_Nom.getText()))){
            JOptionPane.showMessageDialog(null,"Il faut remplir toutes les cases.");
        }else{ 
        ModificationMembre();
        //AfficheInfoMembre();
        }
    }//GEN-LAST:event_Modifier_MembreActionPerformed

        public void InsertionMembre(){
        int Id_Membre = Integer.valueOf(jTextField_ID.getText());
        String Nom_membre = jTextField_Nom.getText();
       
         conn = new Connection_DB();
         conn.InsererMembre(Id_Membre, Nom_membre);
         jTextField_ID.setText("");
         jTextField_Nom.setText("");
      }
   
       public void ModificationMembre(){
        int Id_Membre = Integer.valueOf(jTextField_ID.getText());
        String Nom_membre = jTextField_Nom.getText();
       
         conn = new Connection_DB();
         conn.ModifierMembre(Id_Membre, Nom_membre);
         jTextField_ID.setText("");
         jTextField_Nom.setText("");
      }
       
         //effacer les infos dans la base
        public void SuppressionMembre(int id) { 
          conn = new Connection_DB();
          Rs = conn.Delete_Membre(id);
   }
    
        
       //afficher tous les membres
        public void AfficheInfoMembre(){ 
        try {
            conn = new Connection_DB();
            model.setColumnCount(0);
            model.addColumn("ID Membre");
            model.addColumn("Nom");
            
            model.setRowCount(0);
            Rs = conn.ListerMembre();
            while(Rs.next()){
                Object[] membre = {Rs.getInt(1),Rs.getString(2)
                };
                model.addRow(membre);
            }
            if(model.getRowCount()==0)
                JOptionPane.showMessageDialog(null,"Il n'y a pas de membre!");
            Table_Membre.setModel(model);
        } catch (SQLException ex) {
            Logger.getLogger(Membres.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
        
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Membres.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Membres().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ajouter_Membre;
    private javax.swing.JButton Back_To_Menu;
    private javax.swing.JLabel ID_Membre;
    private javax.swing.JButton Modifier_Membre;
    private javax.swing.JLabel Nom_Membre;
    private javax.swing.JButton Supprimer_Membre;
    private javax.swing.JTable Table_Membre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField_ID;
    private javax.swing.JTextField jTextField_Nom;
    // End of variables declaration//GEN-END:variables
}
