/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1;
import java.sql.*;
import javax.swing.JOptionPane;

public class Connection_DB {
    Connection con;
    Statement stm;
    
    public Connection_DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null, e); //pour afficher l'erreur
        }
        try{
            con=(Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1/TP1","root","qwertyuiop");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
   
    public ResultSet Search_ID_Membre(int ID_Membre){
        ResultSet rs = null;
        try{
            if(stm != null)
                stm.close();
             stm = con.createStatement();
             String requete = "call Task_Search_With_IDMembre('"+ID_Membre+"')";              
             rs = stm.executeQuery(requete); 
         }catch(SQLException e){ 
             JOptionPane.showMessageDialog(null,"    Erreur acces à la table Membre \nVerifier si les informations sont correcte!");
         }
        return rs;
    }
    
     public ResultSet Search_Status_Task(String StatusT){
        ResultSet rs = null;
        try{
           if(stm != null)
            stm.close();
             stm = con.createStatement();
             String requete = "call Task_Search('"+StatusT+"')";              
             rs = stm.executeQuery(requete);    
         }
         catch(SQLException e){ 
             JOptionPane.showMessageDialog(null,"    Erreur acces à la table Tache \nVerifier si les informations sont correcte!");
         }
        return rs;
    }
    
    public void InsererMembre(int ID_Membre,String Nom){
	    try{
	      if(stm != null)
                stm.close();
                 stm = con.createStatement();
	        String requete = "call Member_Insert('"+ID_Membre+"','"+Nom+"')";
	        stm.executeUpdate(requete);
	    }
	    catch(SQLException e){ 
                JOptionPane.showMessageDialog(null,"    Erreur insertion données dans Membre "
                        + "\nVerifier si les informations sont correcte ou si l'ID existe!");
	    }
	   }

    public void InsererTache(int ID_Tache,String Nom,String Description,String StatusT){
	    try{
	      if(stm != null)
                stm.close();
                 stm = con.createStatement();
	        String requete = "call Task_Insert('"+ID_Tache+"','"+Nom+"','"+Description+"','"+StatusT+"')";
	        stm.executeUpdate(requete);
	    }catch(SQLException e){ 
                JOptionPane.showMessageDialog(null,"    Erreur insertion données dans Tache "
                        + "\nVerifier si les informations sont correcte ou si l'ID existe!");
	    }
	   }

    public void InsererAssignation(int ID_Membre,int ID_Tache){
	    try{
	      if(stm != null)
                stm.close();
                 stm = con.createStatement();
	        String requete = "call Assignation_Insert('"+ID_Membre+"','"+ID_Tache+"')";
	        stm.executeUpdate(requete);
	    }catch(SQLException e){ 
                JOptionPane.showMessageDialog(null,"    Erreur d'assigner une tache à un membre "
                        + "\nVerifier si l'ID du membre et l'ID de la tache existe!");
	    }
	   }
    
    public ResultSet Delete_Membre(int ID_Membre){
        ResultSet rs = null;
        try{
          if(stm != null)
           stm.close();
            stm = con.createStatement();
            String requete = "call Member_Delete ('"+ID_Membre+"')";
            rs = stm.executeQuery(requete);              
        }catch(SQLException e){ 
            JOptionPane.showMessageDialog(null,"    Erreur suppresion de Membre dans la base de données \nVerifier si l'ID du membre existe!");
        }
       return rs;
   }  

    public ResultSet Delete_Tache(int ID_Tache){
        ResultSet rs = null;
        try{
          if(stm != null)
           stm.close();
            stm = con.createStatement();
            String requete = "call Task_Delete ('"+ID_Tache+"')";
            rs = stm.executeQuery(requete);              
        }catch(SQLException e){ 
            JOptionPane.showMessageDialog(null,"    Erreur suppresion de Tache dans la base de données \nVerifier si l'ID de la tache existe!");
        }
       return rs;
   }  
    
    public void ModifierMembre(int ID_Membre,String Nom){
        try{
          if(stm != null)
               stm.close();
            stm = con.createStatement();
            String requete = "call Member_Modify('"+ID_Membre+"','"+Nom+"')";
            stm.executeUpdate(requete);
        }catch(SQLException e){ 
            JOptionPane.showMessageDialog(null,"    Erreur modification données dans Membre "
                    + "\nVerifier si les informations sont correcte ou si l'ID existe!");
        }
   }
    
    public void ModifierTache(int ID_Tache,String Nom,String Description,String StatusT){
        try{
          if(stm != null)
                stm.close();
            stm = con.createStatement();
            String requete = "call Task_Modify('"+ID_Tache+"','"+Nom+"','"+Description+"','"+StatusT+"')";
            stm.executeUpdate(requete);
        }catch(SQLException e){ 
            JOptionPane.showMessageDialog(null,"    Erreur modification données dans Tache "
                    + "\nVerifier si les informations sont correcte ou si l'ID existe!");
        }
   }
    
    public ResultSet ListerMembre(){
	   ResultSet rs = null;
    try{
      if(stm != null)
       stm.close();
        stm = con.createStatement();
        String requete = "call Member_List ()";
        rs = stm.executeQuery(requete);              
    }catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"    Erreur afficharge des membres!");
    }
   return rs;
   }
    
    public ResultSet ListerTache(){
	   ResultSet rs = null;
    try{
      if(stm != null)
            stm.close();
        stm = con.createStatement();
        String requete = "call Task_List ()";
        rs = stm.executeQuery(requete);              
    }catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"    Erreur afficharge des taches!");
    }
   return rs;
   }
    
    public ResultSet Lister(){
	   ResultSet rs = null;
    try{
      if(stm != null)
            stm.close();
        stm = con.createStatement();
        String requete = "call Task_List ()";//fait appelle au procedure Task_List() dans la base de donnee
        rs = stm.executeQuery(requete);              
    }catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"    Erreur afficharge des taches!");
    }
   return rs;
   }

    Connection obtenirconnexion(){
        return con;
    }    
}
