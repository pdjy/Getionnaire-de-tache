/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author pro
 */
public class MembresTest {
    
    public MembresTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of InsertionMembre method, of class Membres.
     */
    @Test
    public void  Insert(){
         int Id_Membre = 2;
       String Nom_Membre = "Teacher"; 
    }

    public void testInsertionMembre() {
        System.out.println("InsertionMembre");
        Membres instance = new Membres();
        instance.InsertionMembre();
        int Id_Membre = 2;
        String Nom_Membre = "Teacher";
        instance.conn.InsererMembre(Id_Membre, Nom_Membre);
        
    }

    /**
     * Test of ModificationMembre method, of class Membres.
     */
    
    @Test
     public void Modification(){
       int Id = 2;
       String Nom = "JB"; 
    }
     
    public void testModificationMembre() {
        System.out.println("ModificationMembre");
        Membres instance = new Membres();
        int Id = 2;
        String Nom = "JB";
        instance.ModificationMembre();
        instance.conn.ModifierMembre(Id, Nom); 
    }

    /**
     * Test of SuppressionMembre method, of class Membres.
     */
    @Test
    public void Suppression(){
       int Id = 2;
    }
    
    public void testSuppressionMembre() {
        System.out.println("SuppressionMembre");
        int id = 2;
        Membres instance = new Membres();
        instance.SuppressionMembre(id);
        instance.conn.Delete_Membre(id);
    }

    /**
     * Test of AfficheInfoMembre method, of class Membres.
     */
    /*@Test
    public void testAfficheInfoMembre() {
        System.out.println("AfficheInfoMembre");
        Membres instance = new Membres();
        instance.AfficheInfoMembre();
    }*/

    /**
     * Test of main method, of class Membres.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Membres.main(args);
    }
    
}
